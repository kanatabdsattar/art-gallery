<script setup lang="ts">

</script>
<template>
    <div class="main">
        <h1>Избранное</h1>
    </div>
</template>
<style scoped>
.main{
    width: 100%;
    display: flex;
    justify-content: center;
}
</style>