<script setup lang="ts">
import { ref, onMounted, watch } from 'vue';
import axios from 'axios';

const props = defineProps(['text'])

const randomImages = ref([]);
const searchImages = ref([]);

onMounted(getRandomImages);
async function getRandomImages() {
    try {
        const response = await axios.get('https://api.unsplash.com/photos/random', {
            params: {
                count: 8, 
                client_id: '9_f3Z7k1T1rViSuGBEs1RAlr0MhdWdmwAgc5kKAB0eI', 
            },
        });
        randomImages.value =  response.data;   
        } catch (error) {
        console.error(error);
        }
    }


async function search(text: string) {
    try{
        const response = await axios.get('https://api.unsplash.com/search/photos',{
            params: {
                per_page: 8, 
                client_id: '9_f3Z7k1T1rViSuGBEs1RAlr0MhdWdmwAgc5kKAB0eI', 
                query: text
            },
        });
        console.log(response.data)
        searchImages.value = response.data

    }
    catch(error){
        console.log(error);
    }
}

watch(() => props.text, (newText: string) => {
    search(newText)
})
</script>
<template>
    <div v-if="text" class="grid-container">
        <div v-for="image in searchImages.results" :key="image.id" class="grid-item">
            <router-link :to="'/ImageInfo/' + image.id"><img :src="image.urls.small" :alt="image.alt_description" class="art"></router-link>
        </div>
    </div>
    <div v-else class="grid-container">
        <div v-for="image in randomImages" :key="image.id" class="grid-item">
            <router-link :to="'/ImageInfo/' + image.id"><img :src="image.urls.small" :alt="image.alt_description" class="art"></router-link>
        </div>
    </div>
</template>

<style scoped>
.grid-container {
    width: 900px;
    margin: 0 auto;
    gap: 20px;
    display: grid;
    grid-template-columns: auto auto auto;
}
.grid-item {
  background-color: rgba(255, 255, 255, 0.8);
  /* border: 1px solid rgba(0, 0, 0, 0.8); */
  font-size: 30px;
  text-align: center;
}
.grid-item  img{
    aspect-ratio: 1/1;
    object-fit: cover;
}
.art{
    object-fit: scale-down;
    height: 250px;
    width: 300px;
    object-fit: cover;
}

</style>